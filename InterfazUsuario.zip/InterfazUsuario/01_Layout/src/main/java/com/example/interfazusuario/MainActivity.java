package com.example.interfazusuario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText texto;
    Button boton;
    Button botonreset;
    Button botonmenos;
    int cnt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contadorlinearlayout);

        texto=findViewById(R.id.editTextTextPersonName);
        boton=findViewById(R.id.button);
        botonmenos=findViewById(R.id.buttonmenos);
        botonreset=findViewById(R.id.buttonreset);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cnt++;
                texto.setText(cnt+"");
            }
        });

        botonmenos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cnt--;
                texto.setText(cnt+"");
            }
        });

        botonreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cnt=0;
                texto.setText(cnt+"");
            }
        });

    }
}